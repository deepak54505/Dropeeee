export default function ProductCard({ product }: { product: any }) {
  return (
    <div className="border p-4 rounded-xl shadow-md">
      <img src={product.image} alt={product.name} className="h-40 w-full object-cover rounded" />
      <h2 className="text-lg font-bold mt-2">{product.name}</h2>
      <p className="text-gray-700">₹{product.price}</p>
      <p className="text-sm text-green-600">Commission: ₹{(product.price * 0.05).toFixed(2)}</p>
      <button className="mt-2 w-full bg-blue-600 text-white p-2 rounded">Resell Now</button>
    </div>
  );
}