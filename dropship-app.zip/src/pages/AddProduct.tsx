import { useState } from 'react';
import { db } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';

export default function AddProduct() {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [image, setImage] = useState('');

  const handleSubmit = async () => {
    try {
      await addDoc(collection(db, 'products'), {
        name,
        price: parseFloat(price),
        image
      });
      alert('Product added!');
      setName('');
      setPrice('');
      setImage('');
    } catch (e) {
      console.error('Error adding product: ', e);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-xl font-bold mb-4">➕ Add New Product</h1>
      <input
        type="text"
        placeholder="Product name"
        className="border p-2 mb-2 w-full"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        type="text"
        placeholder="Price"
        className="border p-2 mb-2 w-full"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
      />
      <input
        type="text"
        placeholder="Image URL"
        className="border p-2 mb-2 w-full"
        value={image}
        onChange={(e) => setImage(e.target.value)}
      />
      <button onClick={handleSubmit} className="bg-green-600 text-white px-4 py-2 rounded">
        Add Product
      </button>
    </div>
  );
}