export default function Dashboard() {
  return <div className="p-4">👤 Vendor Dashboard (Coming Soon)</div>;
}