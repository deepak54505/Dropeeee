import React from 'react';

const App = () => {
  return (
    <div>
      <h1>Welcome to Dropee App</h1>
      {/* Add your routes and components here */}
    </div>
  );
};

export default App;
