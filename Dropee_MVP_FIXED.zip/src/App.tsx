import React from 'react';

const App = () => {
  return (
    <div>
      <h1>Dropee App</h1>
      {/* Add routing and components here */}
    </div>
  );
};

export default App;
